import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAooState();
}

class _MyAooState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyWidget(),
    );
  }
}


class MyWidget extends StatefulWidget {
  const MyWidget({Key? key}) : super(key: key);

  @override
  State<MyWidget> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget> {

  late String _localPath;
  late bool _permissionReady;
  late TargetPlatform? platform;
  CancelToken cancelToken = CancelToken();
  var url = "https://dl2.soft98.ir/soft/m/Microsoft.Edge.109.0.1518.61.x86.zip";
  StreamController streamController = StreamController<DownloadStatus>.broadcast();
 // var url = "https://flutter-learn.ir/wp-content/uploads/2022/03/%D8%A7%D9%85%D9%86%DB%8C%D8%AA-%D8%A7%D9%BE%D9%84%DB%8C%DA%A9%DB%8C%D8%B4%D9%86-%D9%81%D9%84%D8%A7%D8%AA%D8%B1.jpeg";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if(Platform.isAndroid){
      platform = TargetPlatform.android;
    }else{
      platform = TargetPlatform.iOS;
    }
  }


  Future<bool> CheckPermission() async{

    if(platform== TargetPlatform.android){
      final status = await Permission.storage.status;
      if(status!= PermissionStatus.granted){
        final result = await Permission.storage.request();
        if(result==PermissionStatus.granted){
          return true;
        }
      }else{
        return true;
      }
    }else {
      return true;
    }
    return false;
  }

  Future<void> _prepareSaveDir() async{
    _localPath = (await _findLocalPath())!;
    print(_localPath);
    final savedDir = Directory(_localPath);
    bool hasExisted = await savedDir.exists();
    if(!hasExisted){
      savedDir.create();
    }
  }

  Future<String?> _findLocalPath()async{

    if(platform==TargetPlatform.android){
      return "/sdcard/download/";
    }else{
      var directory = await getApplicationDocumentsDirectory();
      return directory.path+Platform.pathSeparator+"Download";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Container(
        width: MediaQuery.of(context).size.width,
        child: Column(

          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ElevatedButton(
            onPressed: ()async{

              _permissionReady = await CheckPermission();
              if(_permissionReady){

                await _prepareSaveDir();
                print("Downloading..");
                try{
                  await Dio().download(url,
                      _localPath+"/"+"edge.zip",
                    cancelToken: cancelToken,
                    onReceiveProgress: (count, total) {
                    //  print("Count: $count - Totoal: $total");
                      streamController.add(DownloadStatus(total.toDouble(), count.toDouble()));
                      print("${  (count/total)*100 }%");
                    },
                  );
                  print("DOwnload completed");
                }catch(e){
                  print("Download failed... ${e.toString()}");
                }

              }



            },
          child: Icon(Icons.download_rounded)),

             InkWell(
              child: Text("Cancel"),
              onTap: (){
                cancelToken.cancel();

              },
            ),
            StreamBuilder(
              stream: streamController.stream,
              builder: (context, snapshot) {
                if(snapshot.hasData){
                  return Slider(
                    min: 0.0,
                    max: snapshot.data.max,
                    value: snapshot.data.current,
                    onChanged: (double value) {  },
                  );
                }else{
                  return Text("NOT started yet.");
                }
              },
            )
          ],
        ),
      )
    );
  }
}

class DownloadStatus{
  double max;
  double current;

  DownloadStatus(this.max, this.current);
}