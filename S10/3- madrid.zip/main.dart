import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:season/madrid.dart';



final counterProvider = StateProvider.autoDispose((ref)=>0);

void main(){
  runApp(
      ProviderScope(child: MaterialApp(
        home: MyApp(),
      ))
  );
}
class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  var _madrid_url = "http://flutter-learn.ir/app/madrid.json";
  var _mydata = "";
  void SendRequest() async{

    // get, post, delete, put,
    var url = "http://flutter-learn.ir/app/website.json";
    try{
      var response = await Dio().get(url);

      print("website: ${response.data["website"]}");
      print("topic: ${response.data["topic"]}");
      setState(() {
        _mydata+= response.data["website"] ;
        _mydata += " - ";
        _mydata += response.data["topic"];
      });



    } catch(e){
      print(e.toString());
    }
  }

  Future<List?> getMadrid() async {
    try {
      var response = await Dio().get(_madrid_url);
      print(response.data);
      Iterable userdata = response.data;
      List<Madrid> newlist = userdata.map((e) => Madrid.fromJson(e)).toList();
      return newlist;
    } catch (e) {
      print(e.toString());
    }
  }

    Widget UserItem(List<dynamic> userlist){
      var _style = TextStyle(fontSize: 18.0);

      return ListView.builder(

        itemCount: userlist.length,
        itemBuilder: (context,index){
          return Container(
            color: Colors.white,
            margin: EdgeInsets.symmetric(vertical: 10.0),
            padding: EdgeInsets.symmetric(horizontal: 13.0,vertical: 8.0),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(userlist[index].number!, style: _style,),
                    SizedBox(width: 10.0,),
                    Text(userlist[index].name!, style: _style,),
                  ],
                ),
                SizedBox(height: 6.0,),
                Text(userlist[index].position!, style: _style,),
              ],
            ),
          );
        },

      );
    }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Webservice"),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: (){

          SendRequest();
        },
      ),
      body: Container(
        child: FutureBuilder(
          future: getMadrid(),
          builder: (context,AsyncSnapshot snap){
            if(snap.hasData){
              return UserItem(snap.data);
            }else{
              return Center(child: Text("No data..."),);
            }
          },
        ),
      )
    );
  }
}







