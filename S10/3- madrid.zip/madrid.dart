class Madrid{
  String? name,position,number;

  Madrid({this.name, this.position, this.number});

  Madrid.fromJson(Map<String, dynamic> json){
    name = json['name'];
    position = json['Position'];
    number = json['Number'];
  }

  Map<String , dynamic> toJson(){
    final Map<String,dynamic> data = Map<String, dynamic>();
    data['name'] = this.name;
    data['Position'] = this.position;
    data['Number'] = this.number;
    return data;
  }
}